package com.example.blooddonation.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.ToolbarWidgetWrapper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.LayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.blooddonation.Adapters.RequestAdapter;
import com.example.blooddonation.DataModels.RequestDataModel;
import com.example.blooddonation.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<RequestDataModel> requestDataModels;
    private RequestAdapter requestAdapter;
    @Override

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView make_request_button = findViewById(R.id.make_request_button);
        make_request_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this , MakeRequestActivity.class));
            }
        });
        requestDataModels = new ArrayList<>();
        Toolbar toolbar=findViewById(R.id.toolbar) ;

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                if(item.getItemId()==R.id.search_button)
                {
                    //open search
                    startActivity(new Intent(MainActivity.this , SearchActivity.class));

                }
                return false;
            }
        });
        recyclerView=findViewById(R.id.recyclerView);
        LayoutManager layoutManager=new LinearLayoutManager(this,RecyclerView.VERTICAL,false);
        recyclerView.setLayoutManager(layoutManager);

        requestAdapter = new RequestAdapter(requestDataModels , this);
        recyclerView.setAdapter(requestAdapter);
        populateHomePage();
    }
    private void populateHomePage()
    {
        RequestDataModel requestDataModel = new RequestDataModel("Pratik vitthL Ptil ","https://drive.google.com/file/d/1cRas8ZQTwCwmEA5Axwi8SuTEUPcv_a1b/view?usp=sharing ");
        requestDataModels.add(requestDataModel);
        requestDataModels.add(requestDataModel);
        requestDataModels.add(requestDataModel);
        requestDataModels.add(requestDataModel);
        requestDataModels.add(requestDataModel);
        requestDataModels.add(requestDataModel);
        requestAdapter.notifyDataSetChanged();
    }
}